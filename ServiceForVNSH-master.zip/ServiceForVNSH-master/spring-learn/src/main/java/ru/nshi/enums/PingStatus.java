package ru.nshi.enums;

public enum PingStatus {
    UP,
    DOWN
}
